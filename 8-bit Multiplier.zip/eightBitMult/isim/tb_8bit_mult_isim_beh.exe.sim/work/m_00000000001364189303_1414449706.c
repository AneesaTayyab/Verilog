/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/DELL/Documents/dsd/lab/lab 2/post lab/eightBitMult/tb_8bit_mult.v";
static int ng1[] = {0, 0};
static int ng2[] = {255, 0};
static int ng3[] = {1, 0};



static void Initial_41_0(char *t0)
{
    char t14[8];
    char *t1;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    int t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t15;
    char *t16;

LAB0:    t1 = (t0 + 2528U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(41, ng0);

LAB4:    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(44, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t2 + 4);
    t4 = *((unsigned int *)t3);
    t5 = (~(t4));
    t6 = *((unsigned int *)t2);
    t7 = (t6 & t5);
    t8 = (t0 + 4392);
    *((int *)t8) = t7;

LAB5:    t9 = (t0 + 4392);
    if (*((int *)t9) > 0)
        goto LAB6;

LAB7:
LAB1:    return;
LAB6:    xsi_set_current_line(45, ng0);

LAB8:    xsi_set_current_line(46, ng0);
    t10 = (t0 + 1448);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = ((char*)((ng3)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_add(t14, 32, t12, 8, t13, 32);
    t15 = (t0 + 1448);
    xsi_vlogvar_assign_value(t15, t14, 0, 0, 8);
    xsi_set_current_line(47, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t2 + 4);
    t4 = *((unsigned int *)t3);
    t5 = (~(t4));
    t6 = *((unsigned int *)t2);
    t7 = (t6 & t5);
    t8 = (t0 + 4396);
    *((int *)t8) = t7;

LAB9:    t9 = (t0 + 4396);
    if (*((int *)t9) > 0)
        goto LAB10;

LAB11:    t2 = (t0 + 4392);
    t7 = *((int *)t2);
    *((int *)t2) = (t7 - 1);
    goto LAB5;

LAB10:    xsi_set_current_line(48, ng0);

LAB12:    xsi_set_current_line(49, ng0);
    t10 = (t0 + 2336);
    xsi_process_wait(t10, 10000LL);
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(49, ng0);
    t11 = (t0 + 1608);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t15 = ((char*)((ng3)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_add(t14, 32, t13, 8, t15, 32);
    t16 = (t0 + 1608);
    xsi_vlogvar_assign_value(t16, t14, 0, 0, 8);
    t2 = (t0 + 4396);
    t7 = *((int *)t2);
    *((int *)t2) = (t7 - 1);
    goto LAB9;

}


extern void work_m_00000000001364189303_1414449706_init()
{
	static char *pe[] = {(void *)Initial_41_0};
	xsi_register_didat("work_m_00000000001364189303_1414449706", "isim/tb_8bit_mult_isim_beh.exe.sim/work/m_00000000001364189303_1414449706.didat");
	xsi_register_executes(pe);
}
